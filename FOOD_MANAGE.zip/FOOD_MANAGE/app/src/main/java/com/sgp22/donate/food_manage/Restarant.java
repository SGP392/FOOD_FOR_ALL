package com.sgp22.donate.food_manage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Restarant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restarant);
    }
}